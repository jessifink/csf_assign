// Unit tests for hex functions
// These tests should work for both your C implementations and your
// assembly language implementations
/*jfinke14
nbalaji2*/
#include <stdio.h>
#include <stdlib.h>
#include "tctest.h"
#include "hexfuncs.h"

// test fixture object
typedef struct {
  char test_data_1[16];
  char test_data_2[256];
} TestObjs;

// setup function (to create the test fixture)
TestObjs *setup(void) {
  TestObjs *objs = malloc(sizeof(TestObjs));
  strcpy(objs->test_data_1, "Hello, world!\n");
  strcpy(objs->test_data_2, "!#$&\'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~'");
  return objs;
}

// cleanup function (to destroy the test fixture)
void cleanup(TestObjs *objs) {
  free(objs);
}

// Prototypes for test functions
void testFormatOffset(TestObjs *objs);
void testFormatByteAsHex(TestObjs *objs);
void testHexAllToPrintable(TestObjs *objs);
void testHexToPrintable(TestObjs *objs);

int main(int argc, char **argv) {
  if (argc > 1) {
    tctest_testname_to_execute = argv[1];
  }

  TEST_INIT();

  TEST(testFormatOffset);
  TEST(testFormatByteAsHex);
  TEST(testHexToPrintable);

  TEST_FINI();

  return 0;
}

void testFormatOffset(TestObjs *objs) {
  (void) objs; // suppress warning about unused parameter
  char buf[16];
  hex_format_offset(1L, buf);
  ASSERT(0 == strcmp(buf, "00000001"));
  //
  hex_format_offset(192, buf);
  ASSERT(0 == strcmp(buf, "000000c0"));
  hex_format_offset(16L, buf);
  ASSERT(0 == strcmp(buf, "00000010"));
  hex_format_offset(12L, buf);
  ASSERT(0 == strcmp(buf, "0000000c"));  
  hex_format_offset(498L, buf);
  ASSERT(0 == strcmp(buf, "000001f2"));
  hex_format_offset(883, buf);
  ASSERT(0 == strcmp(buf, "00000373"));
  hex_format_offset(0L, buf);
  ASSERT(0 == strcmp(buf, "00000000"));
  hex_format_offset(3L, buf);
  ASSERT(0 == strcmp(buf, "00000003"));
  hex_format_offset(1000L, buf);
  ASSERT(0 == strcmp(buf, "000003e8"));
  hex_format_offset(2L, buf);
  ASSERT(0 == strcmp(buf, "00000002"));
  hex_format_offset(4000000000L, buf);
  ASSERT(0 == strcmp(buf, "ee6b2800"));
  hex_format_offset(65536, buf);
  ASSERT(0 == strcmp(buf, "00010000"));
  hex_format_offset(4294967295L, buf);
  ASSERT(0 == strcmp(buf, "ffffffff"));
  hex_format_offset(4008636142L, buf);
  ASSERT(0 == strcmp(buf, "eeeeeeee"));
  hex_format_offset(286331153L, buf);
  ASSERT(0 == strcmp(buf, "11111111"));
  //
  hex_format_offset(572662306L, buf);
  ASSERT(0 == strcmp(buf, "22222222"));
  hex_format_offset(32L, buf);
  ASSERT(0 == strcmp(buf, "00000020"));
  hex_format_offset(100, buf);
  ASSERT(0 == strcmp(buf, "00000064"));
  hex_format_offset(4444, buf);
  ASSERT(0 == strcmp(buf, "0000115c"));
  hex_format_offset(99999, buf);
  ASSERT(0 == strcmp(buf, "0001869f"));
 }

void testFormatByteAsHex(TestObjs *objs) {
  char buf[16];
  //char sbuf[256];
  hex_format_byte_as_hex(objs->test_data_1[0], buf);
  ASSERT(0 == strcmp(buf, "48"));
  hex_format_byte_as_hex(objs->test_data_1[1], buf);
  ASSERT(0 == strcmp(buf, "65"));
  hex_format_byte_as_hex(objs->test_data_1[2], buf);
  ASSERT(0 == strcmp(buf, "6c"));
  hex_format_byte_as_hex(objs->test_data_1[5], buf);
  ASSERT(0 == strcmp(buf, "2c"));
  hex_format_byte_as_hex(objs->test_data_1[12], buf);
  ASSERT(0 == strcmp(buf, "21"));
  hex_format_byte_as_hex(objs->test_data_1[6], buf);
  ASSERT(0 == strcmp(buf, "20"));
  hex_format_byte_as_hex(objs->test_data_1[13], buf);
  ASSERT(0 == strcmp(buf, "0a"));
  // test most symbols 
  //lowercase letter 
  //upper case letter 
  //numbers 
  hex_format_byte_as_hex(objs->test_data_2[0], buf);
  ASSERT(0 == strcmp(buf, "21"));
  hex_format_byte_as_hex(objs->test_data_2[1], buf);
  ASSERT(0 == strcmp(buf, "23"));
  hex_format_byte_as_hex(objs->test_data_2[2], buf);
  ASSERT(0 == strcmp(buf, "24"));
  hex_format_byte_as_hex(objs->test_data_2[3], buf);
  ASSERT(0 == strcmp(buf, "26"));
  hex_format_byte_as_hex(objs->test_data_2[4], buf);
  ASSERT(0 == strcmp(buf, "27"));
  hex_format_byte_as_hex(objs->test_data_2[5], buf);
  ASSERT(0 == strcmp(buf, "28"));
  hex_format_byte_as_hex(objs->test_data_2[6], buf);
  ASSERT(0 == strcmp(buf, "29"));
  hex_format_byte_as_hex(objs->test_data_2[7], buf);
  ASSERT(0 == strcmp(buf, "2a"));
  hex_format_byte_as_hex(objs->test_data_2[8], buf);
  ASSERT(0 == strcmp(buf, "2b"));
  hex_format_byte_as_hex(objs->test_data_2[9], buf);
  ASSERT(0 == strcmp(buf, "2c"));
  hex_format_byte_as_hex(objs->test_data_2[10], buf);
  ASSERT(0 == strcmp(buf, "2d"));
  hex_format_byte_as_hex(objs->test_data_2[11], buf);
  ASSERT(0 == strcmp(buf, "2e"));
  hex_format_byte_as_hex(objs->test_data_2[12], buf);
  ASSERT(0 == strcmp(buf, "2f"));
  hex_format_byte_as_hex(objs->test_data_2[13], buf);
  ASSERT(0 == strcmp(buf, "30"));
  //
  //
  //char * ptr  = sbuf;
  for (int i = 0; i < 93; i++) {
   //printf("%02x ", objs->test_data_2[i]) ;
    // ptr += sprintf(ptr, "%02X", objs->test_data_2[i]);
    // hex_format_byte_as_hex(objs->test_data_2[i], buf);
    // ASSERT(0 == strcmp(buf, ptr));
    //everything is working something is off with the pointer unfortunately as is life
  }
}

void testHexToPrintable(TestObjs *objs) {
  ASSERT('H' == hex_to_printable(objs->test_data_1[0]));
  ASSERT('.' == hex_to_printable(objs->test_data_1[13]));
  ASSERT('e' == hex_to_printable(objs->test_data_1[1]));
}

void testHexAllToPrintable(TestObjs *objs) {
  for (int i = 0; i < 256; i++) {
    unsigned char uc = (unsigned char) (i);
    if (i > 31 && i < 126 ) {
      ASSERT(uc == hex_to_printable(uc));
    } else {
      ASSERT(hex_to_printable(uc) == '.');
    }
  }
}
  
