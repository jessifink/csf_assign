jfinke14 - Jessi Finkelstein
nbalaji2 - Nandita Balaji
Jessi worked on:  hex_format_offset, hex_read, hex_write_string
Nandita worked on: hextests
Worked together on : asm_hex_main  

