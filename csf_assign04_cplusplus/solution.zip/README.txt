TODO: describe the contributions of each team member
